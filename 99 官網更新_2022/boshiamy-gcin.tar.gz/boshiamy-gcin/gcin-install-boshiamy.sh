#!/bin/sh

REVDATE="2009.11.02"
VERSION="1.1"

impath=/usr/share/gcin
destpath=$impath/table
iconpath=/usr/share/pixmaps/gcin

curpath=`dirname "$0"`

UseUTF8() {
    S_VERDESC="(相容於 嘸蝦米輸入法 7.0.4 標準版 on MS-Windows)"

    S_PRESS_Y_OR_N="請輸入 y 或 n ..."

    S_COPY="複製"
    S_DONE="完成"
    S_FAILED="失敗"

    S_MISSSOURCE="檔案來源遺失！"

    S_PRESS_ENTER_QUIT="(請按 Enter 鍵結束...)"

    S_EULA="本安裝套件之所有內容（包含表格檔、圖示檔及相關文件）均為 行易有限公司 (http://boshiamy.com) 版權所有。本公司授權合法持有嘸蝦米輸入法 7.0 非試用版之使用者自行利用，惟使用者不得任意更改此表格中每個字的編碼規則以及本套件之任何內容，亦不得以轉換格式或片段節錄等任何方法重新散佈！此表格授權使用範圍與使用者持有之授權合約書所載範圍相同，其他未載明之事項，一律依原授權合約書內容辦理之。"

    S_REVDATE="釋出日期： $REVDATE"
    S_VERSION="表格檔版本： $VERSION $S_VERDESC"

    S_INFO="本安裝程序將為您安裝 嘸蝦米輸入法 gcin 表格檔及其相關圖示檔\n(安裝過程中可能會要求您輸入目前使用者的登入密碼)"
    S_DESTPATH="表格安裝路徑"
    S_ICONPATH="圖示安裝路徑"

    S_CONFIRMINSTALL="您是否確定要安裝？"
    S_ABORT="安裝已中斷！"

    S_NOMODULE="找不到 $impath 路徑，您可能尚未安裝 gcin 模組！"
    S_NOTDEFAULT="您目前的預設輸入法引擎並非是 gcin，是否仍然要安裝？"

    S_NEEDROOT="本程序必須存取 /usr 目錄，而您目前的使用者權限不足！\n請試著登入 root 帳戶再重新操作一次"

    S_CANNOTREMOVE="無法移除舊的 嘸蝦米輸入法 gcin 表格檔，已取消安裝！"

    S_FINISH="安裝結束！\n請重新啟動 gcin 模組，或者重新登入系統"
    
    S_BOSHIAMYEXIST="$destpath/gtab.list 文件中發現已有設定「嘸蝦米輸入法」項目"
    S_CONFIRMEDIT="您是否仍然要設定這個檔案？(建議選 N 不用設定)"
    
    S_OVERWRITEINFO="本安裝程序將使用預先設定好的 gtab.list，\n覆寫您系統中的 $destpath/gtab.list 文件\n而原始文件將備份為同路徑下的 gtab.list.bak\n\n如果您不清楚什麼是 gtab.list 文件，\n或者從未自行安裝過其它輸入法，請選擇「Y」繼續"
    S_CONFIRMOVERWRITE="是否確認要覆寫？"
    
    S_FINISH2="安裝結束！\n您還需要自行編輯 $destpath/gtab.list 文件設定輸入法才能開始使用\n可參考附帶的 gcin-list-sample 文件內容\n編輯完畢後，重新啟動 gcin 模組，或者重新登入系統即可"
    S_CONFIRMOPEN="是否要在結束程序時，幫您用 gedit 開啟上述兩份文件？"
}

UseEng() {
    S_VERDESC="(compatible with \"Boshiamy 7.0.4 Standard\" on MS-Windows)"

    S_PRESS_Y_OR_N="Press 'y' or 'n' ..."

    S_COPY="Copy"
    S_DONE="done"
    S_FAILED="failed"

    S_MISSSOURCE="missed!!"

    S_PRESS_ENTER_QUIT="(Press Enter to exit ...)"

    S_EULA="This package is copyright by Boshiamy C&C Ltd. (http://boshiamy.com)\nYou must read and agree our EULA in README file first."

    S_REVDATE="Release Date： $REVDATE"
    S_VERSION="Tables Version： $VERSION $S_VERDESC"

    S_INFO="This script will install tables and icons of Boshiamy IM in your gcin engine.\n(It may require the password of current user)"
    S_DESTPATH="Tables path: "
    S_ICONPATH="Icons poth: "

    S_CONFIRMINSTALL="Continue? "
    S_ABORT="Abort!"

    S_NOMODULE="'$impath' Path not found!\nThat might be no gcin engine installed in your system..."
    S_NOTDEFAULT="The gcin engine is not your default input method, Cotinue anyway?"

    S_NEEDROOT="Current user account is not enough to access '/usr' !\nTry to log in as root first..."

    S_CANNOTREMOVE="Can't remove former tables of Boshiamy! Installation cancelled!"

    S_FINISH="Finish!\nPlease terminate the gcin engine or reboot your system."

    S_BOSHIAMYEXIST="It's already set \"Boshiamy IM\" in your \"$destpath/gtab.list\" config."
    S_CONFIRMEDIT="Edit anyway? (Suggest: No need)"
    
    
    S_OVERWRITEINFO="This script will overwrite \"$destpath/gtab.list\" by the file we prepared.\nThe old one will be renamed to \"gtab.list.bak\"\n\nPress 'Y' if you have no idea what \"gtab.list\" is or you haven't added any other input methods by yourself."
    S_CONFIRMOVERWRITE="Sure to overwrite?"
    
    S_FINISH2="Finish!\nYou need edit \"$destpath/gtab.list\" config file by yourself before using Boshiamy IM.\nYou can refer to \"./gcin-list-sample\" we prepared as a sample.\nAfter editing, Please terminate the gcin engine or reboot your system."
    S_CONFIRMOPEN="Open the two files above by \"gedit\" after finish?"
}

if echo $LANG | grep -i utf >/dev/null; then
    UseUTF8
else
    UseEng
fi

#################################################

YesNo() {
    msg="$1"
    default="$2"

    while : ; do
        if [ $default = 1 ]; then
            printf "$msg (y/[N]): "
        else
            printf "$msg ([Y]/n): "
        fi

        read answer

        if [ "$answer" ]; then
            case "$answer" in
                "y" | "Y" | "yes" | "Yes")
                    return 0
                           ;;
                "n" | "N" | "no" | "No")
                    return 1
                           ;;
                    *)
                    printf "$S_PRESS_Y_OR_N\n\n"
                    continue
                           ;;
            esac
        else
            return $default
        fi
    done
}

copyfile() {
    if [ -f "$curpath/$2" ]; then
        printf "$S_COPY $2 ... " 
        sudo cp -f "$curpath/$2" $1

        if [ -f $1/$2 ]; then
            echo "$S_DONE"
        else
            echo "$S_FAILED"
        fi
    else
        printf "$2 $S_MISSSOURCE\n"
    fi
}

checkexist() {
    for fname in $2 $3 $4 $5; do
        if [ -f $1/$fname ]; then
            exist=`expr $exist + 1`
        fi
    done
}

checktabs() {
    checkexist $destpath 'boshiamy-t.gtab' 'boshiamy-c.gtab' 'boshiamy-ct.gtab' 'boshiamy-j.gtab'
}

checkicons() {
    checkexist $iconpath 'boshiamy-t.png' 'boshiamy-c.png' 'boshiamy-ct.png' 'boshiamy-j.png'
}

terminal() {
    printf "$S_PRESS_ENTER_QUIT"
    read quit
    exit
}

printf "$S_EULA\n\n"

printf "$S_REVDATE\n"
printf "$S_VERSION\n\n"

printf "===================================================\n\n"

printf "$S_INFO\n\n"
printf "$S_DESTPATH: $destpath\n$S_ICONPATH: $iconpath\n\n"

if ! YesNo "$S_CONFIRMINSTALL" 1; then 
    printf "\n$S_ABORT\n"
    terminal
fi

echo ''

if [ ! -d $impath ]; then
    printf "$S_NOMODULE\n"
    terminal
fi

if ! `echo $XMODIFIERS | grep -i "gcin" > /dev/null`; then
    if YesNo "$S_NOTDEFAULT" 1; then
        echo ''
    else
        printf "\n$S_ABORT\n"
        terminal
    fi
fi

if ! `sudo -l | grep -i "(ALL)" > /dev/null`; then
    printf "\n$S_NEEDROOT\n"
    terminal
fi

echo ''

if [ ! -d $destpath ]; then
    sudo mkdir -p -v $destpath
fi

if [ ! -d $iconpath ]; then
    sudo mkdir -p -v $iconpath
fi

exist=0
checktabs
if [ $exist -gt 0 ];then
    sudo rm $destpath/boshiamy-*.gtab
fi

exist=0
checkicons
if [ $exist -gt 0 ]; then
    sudo rm $iconpath/boshiamy-*.png
fi

exist=0
checktabs
checkicons

if [ $exist -gt 0 ]; then
    printf "$S_CANNOTREMOVE\n"
    sudo -K
    terminal
fi

copyfile $destpath 'boshiamy-t.gtab'
copyfile $destpath 'boshiamy-c.gtab'
copyfile $destpath 'boshiamy-ct.gtab'
copyfile $destpath 'boshiamy-j.gtab'

copyfile $iconpath 'boshiamy-t.png'
copyfile $iconpath 'boshiamy-c.png'
copyfile $iconpath 'boshiamy-ct.png'
copyfile $iconpath 'boshiamy-j.png'

echo ''

if `cat $destpath/gtab.list | grep -i "boshiamy-t.gtab" > /dev/null`; then
    printf "$S_BOSHIAMYEXIST\n"

    if ! YesNo "$S_CONFIRMEDIT" 1; then 
        printf "\n$S_FINISH\n"
        sudo -K
        terminal
    fi
    
    echo ''
fi

printf "$S_OVERWRITEINFO\n\n"

if YesNo "$S_CONFIRMOVERWRITE" 0; then 
    sudo mv -i $destpath/gtab.list $destpath/gtab.list.bak

    echo ''
    copyfile $destpath 'gtab.list'
    
    printf "\n$S_FINISH\n"
    sudo -K
    terminal
fi

printf "\n$S_FINISH2\n\n"

if ! YesNo "$S_CONFIRMOPEN" 0; then
    sudo -K
    exit
fi

sudo gedit $destpath/gtab.list "$curpath/gcin-list-sample"
sudo -K
