#!/bin/sh

impath=/usr/share/gcin
destpath=$impath/table
iconpath=/usr/share/pixmaps/gcin

UseUTF8() {
    S_PRESS_Y_OR_N="請輸入 y 或 n ..."

    S_DONE="完成"
    S_FAILED="失敗"

    S_PRESS_ENTER_QUIT="(請按 Enter 鍵結束...)"

    S_NONEEDUNINSTALL="您的系統中未發現需要移除的檔案！"

    S_INFO="本程序將為您移除 嘸蝦米輸入法 gcin 表格檔及其相關圖示檔\n(移除過程中可能會要求您輸入目前使用者的登入密碼)"
    S_DESTPATH="表格安裝路徑"
    S_ICONPATH="圖示安裝路徑"

    S_CONFIRMUNINSTALL="您是否確定要移除？"
    S_ABORT="程序已中斷！"

    S_NEEDROOT="本移除程序必須存取 /usr 目錄，而您目前的使用者權限不足！\n請試著登入 root 帳戶再重新操作一次"

    S_REMOVETAB="移除表格檔"
    S_REMOVEICON="移除圖示檔"

    S_FINISH="移除結束！\n請重新啟動 gcin 模組，或者重新登入系統"
    
    S_RESTOREINFO="本安裝程序將為您還原 $destpath 路徑下的 gtab.list.bak\n\n如果您不清楚什麼是 gtab.list 文件，\n或者從未自行安裝過其它輸入法，請選擇「Y」繼續"
    S_CONFIRMRESTORE="是否確認要還原？"
    S_RESTORED="已還原 gtab.list"
    
    S_FINISH2="移除結束！\n記得需手動編輯 $destpath/gtab.list 文件移除相關資訊\n再重新啟動 gcin 模組，或者重新登入系統即可"
    S_CONFIRMOPEN="是否要在結束程序時，幫您用 gedit 開啟 gtab.list？"
}

UseEng() {
    S_PRESS_Y_OR_N="Press 'y' or 'n' ..."

    S_DONE="done"
    S_FAILED="failed"

    S_PRESS_ENTER_QUIT="(Press Enter to exit ...)"

    S_NONEEDUNINSTALL="There is no file need remove!"

    S_INFO="This script will uninstall tables and icons of Boshiamy IM in your gcin engine.\n(It may require the password of current user)"
    S_DESTPATH="Tables path: "
    S_ICONPATH="Icons poth: "

    S_CONFIRMUNINSTALL="Continue? "
    S_ABORT="Abort!"

    S_NEEDROOT="Current user account is not enough to access '/usr' !\nTry to log in as root first..."

    S_REMOVETAB="Remove tables"
    S_REMOVEICON="Remove icons"

    S_FINISH="Finish!\nPlease terminate the gcin engine or reboot your system."

    S_RESTOREINFO="This script will restore \"$destpath/gtab.list.bak.\"\n\nPress 'Y' if you have no idea what \"gtab.list\" is or you haven't added any other input methods by yourself."
    S_CONFIRMRESTORE="Sure to restore?"
    S_RESTORED="gtab.list restored!"
    
    S_FINISH2="Finish!\nYou need edit \"$destpath/gtab.list\" config file by yourself to complete uninstall.\nAfter editing, Please terminate the gcin engine or reboot your system."
    S_CONFIRMOPEN="Open \"gtab.list\" by \"gedit\" after finish?"
}

if echo $LANG | grep -i utf >/dev/null; then
    UseUTF8
else
    UseEng
fi

#################################################

YesNo() {
    msg="$1"
    default="$2"

    while : ; do
        if [ $default = 1 ]; then
            printf "$msg (y/[N]): "
        else
            printf "$msg ([Y]/n): "
        fi

        read answer

        if [ "$answer" ]; then
            case "$answer" in
                "y" | "Y" | "yes" | "Yes")
                    return 0
                           ;;
                "n" | "N" | "no" | "No")
                    return 1
                           ;;
                    *)
                    printf "$S_PRESS_Y_OR_N\n\n"
                    continue
                           ;;
            esac
        else
            return $default
        fi
    done
}

checkexist() {
    for fname in $2 $3 $4 $5; do
        if [ -f $1/$fname ]; then
            exist=`expr $exist + 1`
        fi
    done
}

checktabs() {
    checkexist $destpath 'boshiamy-t.gtab' 'boshiamy-c.gtab' 'boshiamy-ct.gtab' 'boshiamy-j.gtab'
}

checkicons() {
    checkexist $iconpath 'boshiamy-t.png' 'boshiamy-c.png' 'boshiamy-ct.png' 'boshiamy-j.png'
}

terminal() {
    printf "$S_PRESS_ENTER_QUIT"
    read quit
    exit
}

#################################################

exist=0
checktabs
checkicons

if [ $exist -eq 0 ]; then 
    printf "$S_NONEEDUNINSTALL\n"
    terminal
fi

printf "$S_INFO\n\n"
printf "$S_DESTPATH: $destpath\n$S_ICONPATH: $iconpath\n\n"

if ! YesNo "$S_CONFIRMUNINSTALL" 1; then 
    printf "\n$S_ABORT\n"
    terminal
fi

echo ''

if ! `sudo -l | grep -i "(ALL)" > /dev/null`; then
    printf "\n$S_NEEDROOT\n"
    terminal
fi

echo ''

exist=0
checktabs

if [ $exist -gt 0 ]; then
    printf "$S_REMOVETAB ... "
    sudo rm $destpath/boshiamy-*.gtab

    exist=0
    checktabs
    
    if [ $exist -gt 0 ]; then 
        echo "$S_FAILED"
    else
        echo "$S_DONE"
    fi
fi

exist=0
checkicons

if [ $exist -gt 0 ]; then
    printf "$S_REMOVEICON ... "
    sudo rm $iconpath/boshiamy-*.png

    exist=0
    checkicons
    
    if [ $exist -gt 0 ]; then
        echo "$S_FAILED"
    else
        echo "$S_DONE"
    fi
fi

echo ''

if [ -f $destpath/gtab.list.bak ]; then
    printf "$S_RESTOREINFO\n\n"

    if YesNo "$S_CONFIRMRESTORE" 0; then 
        sudo mv -f $destpath/gtab.list.bak $destpath/gtab.list
        printf "\n$S_RESTORED\n\n"                    
        printf "$S_FINISH\n"
        sudo -K
        terminal
    fi
fi

printf "\n$S_FINISH2\n\n"

if ! YesNo "$S_CONFIRMOPEN" 0; then
    sudo -K
    exit
fi

sudo gedit $destpath/gtab.list
sudo -K
